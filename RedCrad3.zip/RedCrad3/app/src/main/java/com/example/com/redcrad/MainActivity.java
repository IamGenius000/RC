package com.example.com.redcrad;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

//import android.support.v7.widget.Toolbar;
public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,View.OnClickListener {
    EditText text;
    Button zero,one,two,three,four,five,six,seven,eight,nine;
    Button jia,jian,cheng,chu,chengfang,douhao,dian,tuiwei,qingchu,dengyu,wuqiong,bracesL,bracesR,mbL,mbR,pL,pR,gL,gR;
    Button dianji,genghao;
    Button q,w,e,r,t,y,u,i,o,p,a,s,d,f,g,h,j,k,l,z,x,c,v,b,n,m;
    Button jisuan,help;
    TextView tt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar =findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
      //  ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        //drawer.setDrawerListener(toggle);
       // toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        text = (EditText) findViewById(R.id.t1);
        help=(Button)findViewById(R.id.help);
        q=(Button)findViewById(R.id.q);                                    //字母
        w=(Button)findViewById(R.id.w);
        e=(Button)findViewById(R.id.e);
        r=(Button)findViewById(R.id.r);
        t=(Button)findViewById(R.id.t);
        y=(Button)findViewById(R.id.y);
        u=(Button)findViewById(R.id.u);
        i=(Button)findViewById(R.id.i);
        o=(Button)findViewById(R.id.o);
        p=(Button)findViewById(R.id.p);
        a=(Button)findViewById(R.id.a);
        s=(Button)findViewById(R.id.s);
        d=(Button)findViewById(R.id.d);
        f=(Button)findViewById(R.id.f);
        g=(Button)findViewById(R.id.g);
        h=(Button)findViewById(R.id.h);
        j=(Button)findViewById(R.id.j);
        k=(Button)findViewById(R.id.k);
        l=(Button)findViewById(R.id.l);
        z=(Button)findViewById(R.id.z);
        x=(Button)findViewById(R.id.x);
        c=(Button)findViewById(R.id.c);
        v=(Button)findViewById(R.id.v);
        b=(Button)findViewById(R.id.b);
        n=(Button)findViewById(R.id.n);
        m=(Button)findViewById(R.id.m);
        zero = (Button) findViewById(R.id.zero);                                 // 数字
        one = (Button) findViewById(R.id.one);
        two = (Button) findViewById(R.id.two);
        three = (Button) findViewById(R.id.three);
        four = (Button) findViewById(R.id.four);
        five = (Button) findViewById(R.id.five);
        six = (Button) findViewById(R.id.six);
        seven = (Button) findViewById(R.id.seven);
        eight = (Button) findViewById(R.id.eight);
        nine = (Button) findViewById(R.id.nine);
        jia = (Button) findViewById(R.id.jia);                                      //运算符
        jian = (Button) findViewById(R.id.jian);
        cheng = (Button) findViewById(R.id.cheng);
        chu = (Button) findViewById(R.id.chu);
        chengfang = (Button) findViewById(R.id.chengfang);                           //字符
        douhao = (Button) findViewById(R.id.douhao);
        dian = (Button) findViewById(R.id.dian);
        dianji=(Button)findViewById(R.id.dianji);
        genghao=(Button)findViewById(R.id.genghao);
        dengyu = (Button) findViewById(R.id.dengyu);
        wuqiong= (Button) findViewById(R.id.wuqiong);
        tuiwei = (Button) findViewById(R.id.tuiwei);                                //退格
        qingchu = (Button) findViewById(R.id.qingchu);
        bracesL = (Button) findViewById(R.id.bracesL);                               //括号组
        bracesR = (Button) findViewById(R.id.bracesR);
        mbL = (Button) findViewById(R.id.mbL);
        mbR = (Button) findViewById(R.id.mbR);
        pL = (Button) findViewById(R.id.pL);
        pR = (Button) findViewById(R.id.pR);
        gL=(Button)findViewById(R.id.gL);
        gR=(Button)findViewById(R.id.gR);
        jisuan = (Button) findViewById(R.id.jisuan);
        tt=(TextView)findViewById(R.id.show);
        q.setOnClickListener(this);
        w.setOnClickListener(this);
        e.setOnClickListener(this);
        r.setOnClickListener(this);
        t.setOnClickListener(this);
        y.setOnClickListener(this);
        u.setOnClickListener(this);
        i.setOnClickListener(this);
        o.setOnClickListener(this);
        p.setOnClickListener(this);
        a.setOnClickListener(this);
        s.setOnClickListener(this);
        d.setOnClickListener(this);
        f.setOnClickListener(this);
        g.setOnClickListener(this);
        h.setOnClickListener(this);
        j.setOnClickListener(this);
        k.setOnClickListener(this);
        l.setOnClickListener(this);
        z.setOnClickListener(this);
        x.setOnClickListener(this);
        c.setOnClickListener(this);
        v.setOnClickListener(this);
        b.setOnClickListener(this);
        n.setOnClickListener(this);
        m.setOnClickListener(this);
        zero.setOnClickListener(this);
        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        seven.setOnClickListener(this);
        eight.setOnClickListener(this);
        nine.setOnClickListener(this);
        jia.setOnClickListener(this);
        jian.setOnClickListener(this);
        cheng.setOnClickListener(this);
        chu.setOnClickListener(this);
        chengfang.setOnClickListener(this);
        douhao.setOnClickListener(this);
        dian.setOnClickListener(this);
        dianji.setOnClickListener(this);
        genghao.setOnClickListener(this);
        tuiwei.setOnClickListener(this);
        qingchu.setOnClickListener(this);
        dengyu.setOnClickListener(this);
        wuqiong.setOnClickListener(this);
        bracesL.setOnClickListener(this);
        bracesR.setOnClickListener(this);
        mbL.setOnClickListener(this);
        mbR.setOnClickListener(this);
        pL.setOnClickListener(this);
        pR.setOnClickListener(this);
        gL.setOnClickListener(this);
        gR.setOnClickListener(this);
        jisuan.setOnClickListener(this);
        help.setOnClickListener(this);
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_function)
        {

        } else if (id == R.id.nav_linear)
        {
            Intent intent=new Intent(MainActivity.this,help_matrixActivity.class);
            startActivityForResult(intent, 1);
        }
        else if(id==R.id.nav_vector)
        {
            Intent intent=new Intent(MainActivity.this,help_vectorActivity.class);
            startActivityForResult(intent, 3);
        }
        else if (id == R.id.nav_probability)
        {
            Intent intent=new Intent(MainActivity.this,help_probabilityActivity.class);
            startActivityForResult(intent, 2);
        }
        else if (id == R.id.nav_geometry)
        {

        }
        else if (id == R.id.nav_Calculus)
        {

        }
        else if (id == R.id.nav_census)
        {

        }
        else if(id==R.id.nav_share)
        {

        }
        else if(id==R.id.nav_about)
        {

        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.q)                                                      //字母
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="q";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i+1);
        }
        if(v.getId()==R.id.w)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="w";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.e)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="e";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.r)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="r";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.t)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="t";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.y)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="y";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.u)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="u";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.i)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="i";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.o)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="o";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.p)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="p";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.a)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="a";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.s)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="s";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.d)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="d";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.f)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="f";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.g)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="g";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.h)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="h";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.j)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="j";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.k)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="k";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.l)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="l";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.z)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="z";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.x)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="x";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.c) {
            String st;
            String ll;
            String lll;
            int i = text.getSelectionStart();
            st = text.getText().toString();
            ll = st.substring(0, i);
            ll += "c";
            lll = st.substring(i, st.length());
            ll += lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.v)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="v";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.b)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="b";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.n)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="n";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.m)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="m";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.zero)                                  //数字
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="0";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.one)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="1";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.two)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="2";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.three)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="3";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.four)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="4";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.five)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="5";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.six)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="6";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.seven)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="7";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.eight)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="8";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.nine)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="9";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.jia)                                                        //运算符
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="+";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.jian)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="-";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.cheng)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="*";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.chu)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="/";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.tuiwei)                                       //退格
        {
            String st;
            String ll;
            String lll;
            int i;
            i=text.getSelectionStart();
            if(i!=0) {
                st = text.getText().toString();
                if(i==text.length()) {
                    ll = st.substring(0, st.length() - 1);
                    i=ll.length();
                }
                else
                {
                    ll=st.substring(0,i-1);
                    lll=st.substring(i,text.length());
                    i=ll.length();
                    ll+=lll;
                }
                text.setText(ll);
                text.setSelection(i);
            }
        }
        if(v.getId()==R.id.qingchu)
        {
            text.setText("");
        }
        if(v.getId()==R.id.dengyu)                                                    //字符
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="=";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.wuqiong)                                                    //字符
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="∞";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.chengfang)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="^";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.douhao)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+=",";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.dian)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+=".";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.dianji)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="·";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.genghao)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="√";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.bracesL)                                       //括号组
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="{";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.bracesR)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="}";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.mbL)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="[";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.mbR)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="]";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.pL)
        {
            String st;
            String ll;
            String lll;
            int i=text.getSelectionStart();
            st=text.getText().toString();
            ll=st.substring(0,i);
            ll+="(";
            lll=st.substring(i,st.length());
            ll+=lll;
            text.setText(ll);
            text.setSelection(i + 1);
        }
        if(v.getId()==R.id.pR)
        {
            String st;
            String ll;
            String lll;
            int i = text.getSelectionStart();
            st = text.getText().toString();
            ll = st.substring(0, i);
            ll += ")";
            lll = st.substring(i, st.length());
            ll += lll;
            text.setText(ll);
            text.setSelection(i + 1);

        }
        if(v.getId()==R.id.gL)                                       //光标移动
        {
            int i=text.getSelectionStart();
            if(i!=0)
                text.setSelection(i - 1);
        }
        if(v.getId()==R.id.gR)
        {
            int i=text.getSelectionStart();
            if(i!=text.getText().toString().length())
                text.setSelection(i + 1);
        }
        if(v.getId()==R.id.jisuan)                          //计算
        {
            Intent intent=new Intent(MainActivity.this,showActivity.class);
            Bundle bundle=new Bundle();
            bundle.putCharSequence("out", text.getText().toString());
            intent.putExtras(bundle);
            startActivity(intent);
        }
        if(v.getId()==R.id.help)
        {
            Intent intent=new Intent(MainActivity.this,help_matrixActivity.class);
            startActivityForResult(intent, 1);                                                                 //回滚数据1为请求码
        }
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {                       //回滚数据重写
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:
                if (resultCode == RESULT_OK) {
                    String getData = data.getStringExtra("help");
                    text.setText(getData);
                }
            case 2:
                if (resultCode == RESULT_OK) {
                    String getData = data.getStringExtra("help");
                    text.setText(getData);
                }
            case 3:
                if (resultCode == RESULT_OK) {
                    String getData = data.getStringExtra("help");
                    text.setText(getData);
                }
                break;
            default:
        }
    }
}
