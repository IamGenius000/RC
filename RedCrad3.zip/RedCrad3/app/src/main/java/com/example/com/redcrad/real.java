package com.example.com.redcrad;

import java.util.ArrayList;
public class real
{
	ArrayList<realbase> lisMol = null;
	ArrayList<realbase> lisDen = null;
	public real() {
		lisMol = new ArrayList<realbase>();
		lisDen = new ArrayList<realbase>();
		lisMol.add(new realbase("0"));
		lisDen.add(new realbase("1"));
	}

	public real(String str) {
		lisMol = new ArrayList<realbase>();
		lisDen = new ArrayList<realbase>();
		realbase r = new realbase(str);
		realbase mol = new realbase();
		mol.molecule = r.molecule;
		mol.rootMol = r.rootMol;
		lisMol.add(mol);
		realbase den = new realbase();
		den.molecule = r.Denominator;
		den.rootMol = r.rootDen;
		lisDen.add(den);
	}

	public real add(real tmp)
	{
		real rea2 = new real();
		rea2.lisDen = solve(this.lisDen, tmp.lisDen);
		rea2.lisMol = solve(this.lisMol, tmp.lisDen);
		for (realbase r : solve(this.lisDen, tmp.lisMol))
		{
			boolean flag = true;
			for (realbase f : rea2.lisMol)
			{
				if (r.equals(f))
				{
					rea2.lisMol.remove(f);
					rea2.lisMol.add(r.add(f));
					flag = false;
					break;
				}
			}
			if (flag)
			{
				rea2.lisMol.add(r);
			}
		}
		rea2.optimization();
		return rea2;
	}

	public real sub(real tmp)
	{
		real rea2 = new real();
		rea2.lisDen = solve(this.lisDen, tmp.lisDen);
		rea2.lisMol = solve(this.lisMol, tmp.lisDen);
		for (realbase r : solve(this.lisDen, tmp.lisMol))
		{
			boolean flag = true;
			for (realbase f : rea2.lisMol)
			{
				if (r.equals(f))
				{
					rea2.lisMol.remove(f);
					rea2.lisMol.add(f.sub(r));
					flag = false;
					break;
				}
			}
			if (flag)
			{
				r.molecule = -r.molecule;
				rea2.lisMol.add(r);
			}
		}
		rea2.optimization();
		return rea2;
	}

	public real mul(real tmp)
	{
		real rea2 = new real();
		rea2.lisMol = solve(this.lisMol, tmp.lisMol);
		rea2.lisDen = solve(this.lisDen, tmp.lisDen);
		rea2.optimization();
		return rea2;
	}

	public real div(real tmp)
	{
		real rea2 = new real();
		rea2.lisMol = solve(this.lisMol, tmp.lisDen);
		rea2.lisDen = solve(this.lisDen, tmp.lisMol);
		rea2.optimization();
		return rea2;
	}

	public ArrayList<realbase> solve(ArrayList<realbase> a, ArrayList<realbase> b)
	{
		ArrayList<realbase> lis = new ArrayList<realbase>();
		realbase tmp;
		boolean flag;
		for (realbase t1 : a)
			for (realbase t2 : b)
			{
				tmp = t1.mul(t2);
				flag = true;
				for (int i = 0;i < lis.size();i++)
				{
					realbase r = lis.get(i);
					if (r.equals(tmp))
					{
						lis.remove(r);
						lis.add(r.add(tmp));
						// lis.get(i).add(tmp);
						flag = false;
					}
					break;
				}
				if (flag)
					lis.add(tmp);
			}
		return lis;
	}

	public long gcd(long a, long b)
	{
		long c;
		while (b > 0)
		{
			c = a;
			a = b;
			b = c % b;
		}
		return a;
	}

	public void optimization()
	{
		long k1 = (long)Math.abs(this.lisMol.get(0).molecule);
		for (int i = 1; i < this.lisMol.size(); i++)
		{
			k1 = gcd((long)Math.abs(k1), (long)Math.abs(this.lisMol.get(i).molecule));
			if (k1 == 1)
				break;
		}
		long k2 = (long)Math.abs(this.lisDen.get(0).molecule);
		for (int i = 1; i < this.lisDen.size(); i++)
		{
			k2 = gcd((long)Math.abs(k2), (long)Math.abs(this.lisDen.get(i).molecule));
			if (k2 == 1)
				break;
		}
		k1 = gcd(k1, k2);
		if (k1 > 1)
		{
			ArrayList<realbase> lis = new ArrayList<realbase>();
			for (realbase r : this.lisMol)
			{
				r.molecule /= k1;
				lis.add(r);
			}
			this.lisMol = lis;
			ArrayList<realbase> list = new ArrayList<realbase>();
			for (realbase r : this.lisDen)
			{
				r.molecule /= k1;
				list.add(r);
			}
			this.lisDen = list;
		}
	}

	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		String ans;
		if (this.lisMol.size() > 1)
			sb.append("(");
		for (realbase r : lisMol)
		{
			String str = r.toString();
			if (str.startsWith("-"))
			{
				sb.append(str);
			}
			else
			{
				sb.append("+");
				sb.append(str);
			}
		}
		if (this.lisMol.size() > 1)
			sb.append(")");
		if (lisDen.size() <= 1 && lisDen.get(0).toString().equals("1"))
			ans = sb.toString();
		else
		{
			sb.append("/");
			if (this.lisDen.size() > 1)
				sb.append("(");
			for (realbase r : lisDen)
			{
				String str = r.toString();
				if (str.startsWith("-"))
				{
					sb.append(str);
				}
				else
				{
					sb.append("+");
					sb.append(str);
				}
			}
			if (this.lisDen.size() > 1)
				sb.append(")");
			ans = sb.toString();
		}
		ans = ans.replace("(+", "(");
		ans = ans.replace("/+", "/");
		if(ans.startsWith("+"))
			return ans.substring(1);
		return ans;
	}
}